import java.util.Scanner;

public class Exercise10_07 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		ATMAccount[] accounts = new ATMAccount[10];
		
		initialBalance(accounts);
		
		do {
			System.out.print("Enter an id: ");
			int id = input.nextInt();
			
			if (isValidId(id, accounts)) {
				int menu;
				do {
					menu = mainMenu(input);
					if (menuMovement(menu)) {
							mainMenuChoices(menu, accounts, id, input);
					}
				}
				while (menu != 4);
			}
		}
		while (true);
	}

	public static void initialBalance(ATMAccount[] a) {
		int initialBalance = 100;
		for (int i = 0; i < a.length; i++) {
			a[i] = new ATMAccount(i, initialBalance);
		}
	}
	
	public static int mainMenu(Scanner input) {
		System.out.print("\nMain menu\n1: Check balance\n2: Withdraw \n3: Deposit\n4: Exit\nEnter a choice: ");
		return input.nextInt();
	}
	
	public static boolean isValidId(int id, ATMAccount[] a) {
		for (int i = 0; i < a.length; i++) {
			if (id == a[i].getId())
				return true;
		}
		return false;
	}

	public static boolean menuMovement(int menu) {
		return menu > 0 && menu < 4;
	}

	public static void mainMenuChoices( int menu, ATMAccount[] a, int id, Scanner input) {
		switch (menu) {
			case 1: System.out.println("The balance is " + a[id].getBalance()); break;
			case 2: System.out.print("Enter an amount to withdraw: "); 
				a[id].withdraw(input.nextDouble()); break;
			case 3: System.out.print("Enter an amount to deposit: "); 
				a[id].deposit(input.nextDouble()); break;
		}
	}
}