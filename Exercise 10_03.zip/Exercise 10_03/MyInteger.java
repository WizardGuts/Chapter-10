public class MyInteger {
	
	private int value;
	
	MyInteger(int value) {
		this.value = value;
	}
	
	public int getValue() {
		return value;
	}
	
	public boolean isEven() {
		return isEven(value);
	}
	
	public boolean isOdd() {
		return isOdd(value);
	}
	
	public boolean isPrime() {
		return isPrime(value);
	}
	
	public static boolean isEven(int value) {
		return value % 2 == 0;
	}
	
	public static boolean isOdd(int value) {
		return value % 2 != 0;
	}
	
	public static boolean isPrime(int value) {
		for ( int i = 2; i <= value / 2; i++) {
			if (value % i == 0) 
				return false;
		}
		return true;
	}
	
	public boolean isEven(MyInteger myInteger) {
		return myInteger.isEven();
	}
	
	public boolean isOdd(MyInteger myInteger) {
		return myInteger.isOdd();
	}
	
	public boolean isPrime(MyInteger myInteger) {
		return myInteger.isPrime();
	}
	
	
	public boolean equals(int value) {
		return this.value == value;
	}
	
	public static int parseInt(char[] chars) {
		int value = 0;
		for (int i = 0, c = (int)Math.pow(10, chars.length -1); i < chars.length; i++, c /= 10) {
			value += (chars[i] - 48) * c;
		}
		return value;
	}
	
	public static int parseInt(String strings) {
		int value = 0;
		for (int i = 0, c = (int)Math.pow(10, strings.length() -1); i < strings.length(); i++, c /= 10) {
			value += (strings.charAt(i) - 48) * c;
		}
		return value;
	}
}