import java.util.Scanner;

public class Exercise10_03 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		int[] values = {3, 4, 5, 6, 7};
		
		System.out.println("\nIs the value even through isEven(): ");
			for (int i=0; i < values.length; i++) {
				MyInteger value = new MyInteger(values[i]);
				System.out.println(value.getValue() + " " + value.isEven());
			}
		
		System.out.println("\nIs the value odd through isOdd(): ");
			for (int i=0; i < values.length; i++) {
				MyInteger value = new MyInteger(values[i]);
				System.out.println(value.getValue() + " " + value.isOdd());
			}
		
		System.out.println("\nIs the value prime through isPrime(): ");
			for (int i=0; i < values.length; i++) {
				MyInteger value = new MyInteger(values[i]);
				System.out.println(value.getValue() + " " + value.isPrime());
			}
		System.out.println("Is the value even through isEven(int): ");
			for (int i=0; i < values.length; i++) {
				System.out.println(values[i] + " " + MyInteger.isEven(values[i]));
			}
		
		System.out.println("\nIs the value odd through isOdd(int): ");
			for (int i=0; i < values.length; i++) {
				System.out.println(values[i] + " " + MyInteger.isOdd(values[i]));
			}
		
		System.out.println("\nIs the value prime through isPrime(int): ");
			for (int i=0; i < values.length; i++) {
				System.out.println(values[i] + " " + MyInteger.isPrime(values[i]));
			}
		
		System.out.println("\nIs the value even through isEven(MyInteger): ");
			for (int i=0; i < values.length; i++) {
				MyInteger value = new MyInteger(values[i]);
				System.out.println(value.getValue() + " " + MyInteger.isEven(values[i]));
			}
		
		System.out.println("\nIs the value odd through isOdd(MyInteger): ");
			for (int i=0; i < values.length; i++) {
				MyInteger value = new MyInteger(values[i]);
				System.out.println(value.getValue() + " " + MyInteger.isOdd(values[i]));
			}
		
		System.out.println("\nIs the value prime through isPrime(MyInteger): ");
			for (int i=0; i < values.length; i++) {
				MyInteger value = new MyInteger(values[i]);
				System.out.println(value.getValue() + " " + MyInteger.isPrime(values[i]));
			}
		
		int[] values2 = {3, 5, 7};
		
		MyInteger value = new MyInteger(1);
		
		System.out.println("\nIs " + value.getValue() + " equal to the value: ");
		for (int i = 0; i < values2.length; i++) {
			System.out.println(values2[i] + " " + value.equals(values2[i]));
		}
		
		System.out.println("\nIs " + value.getValue() + " equal to the value: ");
		for (int i = 0; i < values2.length; i++) {
			MyInteger myInteger = new MyInteger(values2[i]);
			System.out.println(values2[i] + " " + value.equals(myInteger));
		}
		
		System.out.println("\nTesting parseInt(char[]) along with parseInt(String): ");
		char[] characters = {'4', '6', '8'};
		String strings = "123";
		
		System.out.print(" ");
		for (int i= 0; i < characters.length; i++) {
			System.out.print(characters[i] + " ");
		}
		
		System.out.println(" + " + strings + " = " + (MyInteger.parseInt(characters) + MyInteger.parseInt(strings)));
	}
}